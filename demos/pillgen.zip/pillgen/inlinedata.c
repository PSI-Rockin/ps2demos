// inlinedata.c

#include "3dmath.h"
#include "generate.h"




